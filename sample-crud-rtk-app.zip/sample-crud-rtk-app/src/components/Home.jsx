import React from "react";
import img1 from "../assets/img1.png";
import img2 from "../assets/img2.png";
import img3 from "../assets/img3.png";

const Home = () => {
  return (
    <div className="p-8 bg-white rounded-lg shadow dark:bg-gray-800">
      <p className="text-3xl font-bold text-center text-gray-800 dark:text-white">
        Professional Team
      </p>
      <p className="mb-12 text-xl font-normal text-center text-gray-500 dark:text-gray-200">
        Domain Service
      </p>
      <div className="flex flex-col items-center md:flex-row justify evenly">
        <div className="p-4">
          <div className="mb-4 text-center opacity-90">
            <a href="#" className="relative block">
              <img
                alt="profil"
                src={img1}
                className="mx-auto object-cover rounded-full h-40 w-40 "
              />
            </a>
          </div>
          <div className="text-center">
            <p className="text-2xl text-gray-800 dark:text-white">
              Akhilesh Kumar
            </p>
            <p className="text-xl font-light text-gray-500 dark:text-gray-200">
              Technical lead, Hyderabad
            </p>
            <p className="max-w-xs py-4 font-light text-gray-500 text-md dark:text-gray-400 text-justify">
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit
              corporis esse totam reiciendis, culpa repudiandae est optio dicta
              excepturi perferendis voluptates consequuntur eaque tempore
              magnam?
            </p>
          </div>
        </div>
        <div className="p-4">
          <div className="mb-4 text-center opacity-90">
            <a href="#" className="relative block">
              <img
                alt="profil"
                src={img2}
                className="mx-auto object-cover rounded-full h-40 w-40"
              />
            </a>
          </div>
          <div className="text-center">
            <p className="text-2xl text-gray-800 dark:text-white">Shyam</p>
            <p className="text-xl font-light text-gray-500 dark:text-gray-200">
              UI Developer
            </p>
            <p className="max-w-xs py-4 font-light text-gray-500 text-md dark:text-gray-400 text-justify">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam
              fugit tempora similique placeat doloribus repellat maiores magnam
              aperiam culpa porro voluptates quaerat, aliquam distinctio ullam.
            </p>
          </div>
        </div>
        <div className="p-4">
          <div className="mb-4 text-center opacity-90">
            <a href="#" className="relative block">
              <img
                alt="profil"
                src={img3}
                className="mx-auto object-cover rounded-full h-40 w-40"
              />
            </a>
          </div>
          <div className="text-center">
            <p className="text-2xl text-gray-800 dark:text-white">Deepthi</p>
            <p className="text-xl font-light text-gray-500 dark:text-gray-200">
              Team Lead, Hyderabad
            </p>
            <p className="max-w-xs py-4 font-light text-gray-500 text-md dark:text-gray-400 text-justify">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur,
              veritatis deserunt repellendus itaque dicta repudiandae voluptate
              delectus maxime tenetur debitis!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
