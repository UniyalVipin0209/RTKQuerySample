import React from 'react'
import { useGetEmployeeByIdQuery } from "../../Services/employeeapiSlice";
const EmployeeDetails = () => {
    const {data: info, isLoading, isError}= useGetEmployeeByIdQuery();
  return (

<div class="relative flex min-h-screen flex-col justify-center overflow-hidden bg-gray-50 py-6 sm:py-12">
  <div class="w-full items-center mx-auto max-w-screen-lg">
    <div class="group grid w-full grid-cols-2">
        <div class="pl-12">
          <p class="peer mb-6 text-gray-400">
            {info.name}
          </p>
          <p class="mb-6 text-gray-400">
          {info.email}
          </p>
          <h3 class="mb-4 font-semibold text-xl text-gray-400">{info.position}</h3>
          <ul role="list" class="marker:text-sky-400 list-disc pl-5 space-y-3 text-slate-500">
            <li>5 cups chopped Porcini mushrooms</li>
            <li>1/2 cup of olive oil</li>
            <li>3lb of celery</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
  )
}

export default EmployeeDetails