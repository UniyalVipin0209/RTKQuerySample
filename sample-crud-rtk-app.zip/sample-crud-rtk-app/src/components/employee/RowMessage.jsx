import React from "react";

const RowMessage = ({ messagestyle, message }) => {
  return (
    <tr className="border-b border-gray-200">
      <td colSpan="4" className="px-5 py-5  gap-3 text-sm bg-white ">
        <div className="flex items-center">
          <div className="ml-5">
            <p className={messagestyle}>
              <span className="font-bold">{message}</span>
            </p>
          </div>
        </div>
      </td>
    </tr>
  );
};

export default RowMessage;
