import React, { useState } from "react";
import { useAddEmployeeMutation } from "../../Services/employeeapiSlice";
import EmployeeModel from "./../../models/Employee";

const AddEmployee = () => {
  const [newEmployee, setNewEmployee] = useState(new EmployeeModel());

  const [addEmployee] = useAddEmployeeMutation();
  const handleEmployee = (e) => {
    e.preventDefault();
    const currentEmployeeData = { ...newEmployee };
    currentEmployeeData[e.target.name] = e.target.value;
    setNewEmployee(currentEmployeeData);
  };
  const createNewEmployee = (e) => {
    e.preventDefault();
    const employee = { ...newEmployee };
    employee.id = parseInt(Math.random(20, 300) * 10) + 1;
    addEmployee(employee);
    setNewEmployee(new EmployeeModel());
  };

  return (
    <div className="flex flex-col max-w  py-8 bg-white rounded-lg shadow dark:bg-gray-800  lg:px-10">
      <div className="p-2 mt-2 w-full">
        <form action="  ">
          <div className="flex flex-col mb-2">
            <div className=" relative mx-4">
              <h2 className="font-bold">Add Employee</h2>{" "}
            </div>
          </div>
          <div className="flex gap-6 mb-4">
            <div className=" relative ">
              <input
                type="text"
                id="fname"
                value={newEmployee.fname}
                onChange={handleEmployee}
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                name="fname"
                required
                placeholder="First Name"
              />
            </div>
            <div className="relative">
              <input
                type="text"
                id="lname"
                value={newEmployee.lname}
                onChange={handleEmployee}
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                name="lname"
                placeholder="Last Name"
              />
            </div>
            <div className=" relative ">
              <input
                type="text"
                id="email"
                name="email"
                value={newEmployee.email}
                onChange={handleEmployee}
                required
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                placeholder="Email"
              />
            </div>
            <div className="relative">
              <input
                type="text"
                id="organization"
                name="organization"
                value={newEmployee.organization}
                onChange={handleEmployee}
                required
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                placeholder="Organization"
              />
            </div>
            <div className="relative">
              <input
                type="date"
                id="doj"
                name="doj"
                required
                value={newEmployee.doj}
                onChange={handleEmployee}
                className="rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                placeholder="Doj"
              />
            </div>
          </div>
          <div className="flex gap-6 mb-1">
            <div className="relative">
              <input
                type="text"
                id="position"
                name="position"
                value={newEmployee.position}
                onChange={handleEmployee}
                required
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                placeholder="Position"
              />
            </div>
            <div className="relative">
              <input
                type="textarea"
                row="5"
                col="10"
                id="address"
                value={newEmployee.address}
                onChange={handleEmployee}
                className=" rounded-lg border-transparent flex-1 appearance-none border border-gray-300 w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-gray-600 focus:border-transparent"
                name="address"
                placeholder="Address"
              />
            </div>
            <div className="relative gap-8"></div>
            <div className="relative float-right">
              <div className="flex mx-4 gap-10">
                <button
                  onClick={createNewEmployee}
                  className="py-2 w-24 px-4 w-60 mx-4  bg-gray-600 hover:bg-gray-700 focus:ring-gray-500 focus:ring-offset-gray-200 text-white w-full transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2  rounded-lg "
                >
                  Create
                </button>

                <button className="py-2 px-4 mx-4 w-60 bg-red-600 hover:bg-red-700 focus:ring-red-500 focus:ring-offset-gray-200 text-white w-full transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2  rounded-lg ">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEmployee;
