import React from "react";

const Header = () => {
  return (
    <thead>
      <tr>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 font-bold"
        >
          User Name
        </th>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 "
        >
          Position
        </th>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 font-bold"
        >
          Organization
        </th>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 font-bold"
        >
          Date Of Joining
        </th>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 font-bold"
        >
          Status
        </th>
        <th
          scope="col"
          className="px-5 py-3 text-sm font-bold text-left text-gray-800 uppercase bg-white border-b border-gray-200 font-bold"
        ></th>
      </tr>
    </thead>
  );
};

export default Header;
