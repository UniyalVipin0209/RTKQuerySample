import React from "react";
import Header from "./Header";
import RowItem from "./RowItem";
import { useGetEmployeesQuery } from "../../Services/employeeapiSlice";
import RowMessage from "./RowMessage";
import AddEmployee from "./AddEmployee";
const List = () => {
  const { data: employeeList, isLoading, isError } = useGetEmployeesQuery();

  return (
    <div className="container max-w-1xl px-4 mx-auto sm:px-8">
      <div className="px-2 py-4">
        <AddEmployee />
      </div>

      <div className="py-10">
        <div className="px-4 py-4 -mx-4 overflow-x-auto sm:-mx-6 sm:px-6">
          <div className="inline-block min-w-full overflow-hidden rounded-lg shadow">
            <table className="min-w-full leading-normal">
              <Header />
              <tbody>
                {isLoading ? (
                  <RowMessage
                    messagestyle="bg-teal-100"
                    message="Loading Data..."
                  />
                ) : isError ? (
                  <RowMessage
                    messagestyle="bg-orange-100"
                    message="Error while fetching the data"
                  />
                ) : (
                  employeeList.map((employee) => (
                    <RowItem key={employee.id} info={employee} />
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default List;
