import React, { useState } from "react";
import { AiFillDelete, AiFillEdit } from "react-icons/ai";
import { RiAddCircleFill } from "react-icons/ri";

import { useDeleteEmployeeMutation } from "../../Services/employeeapiSlice";
const RowItem = ({ info }) => {
  const [selectedRow, setSelectedRow] = useState();
  const fullname = `${info.fname} ${info.lname}`;
  const [deleteEmployee] = useDeleteEmployeeMutation();

  return (
    <tr key={info.id}>
      <td className="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <div className="flex items-center">
          <div className="ml-3">
            <p className="text-gray-900 whitespace-no-wrap">
              {fullname.toLocaleUpperCase()}
            </p>
          </div>
        </div>
      </td>
      <td className="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <p className="text-gray-900 whitespace-no-wrap">
          <span className="font-bold">{info.position}</span>
        </p>
      </td>
      <td className="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <p className="text-gray-900 whitespace-no-wrap">{info.organization}</p>
      </td>
      <td className="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <p className="text-gray-900 whitespace-no-wrap">{info.doj}</p>
      </td>
      <td className="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <span className="relative inline-block px-3 py-1 font-semibold leading-tight text-green-900">
          <span
            aria-hidden="true"
            className={`absolute inset-0 ${
              info.isactive ? "bg-green-200" : "bg-red-200"
            } rounded-full opacity-50`}
          ></span>
          <span className="relative">active</span>
        </span>
      </td>
      <td className="px-1 py-5 text-sm bg-white border-b border-gray-200">
        <div className="flex gap-3">
          <RiAddCircleFill
            style={{
              color: "blue",
              fontSize: "1.4rem",
              margin: ".45rem",
            }}
          />
          <AiFillDelete
            style={{
              color: "red",
              fontSize: "1.4rem",
              margin: ".45rem",
            }}
            title="Delete"
            onClick={() => deleteEmployee({ id: info.id })}
          />
          <AiFillEdit
            style={{
              color: "gray",
              fontSize: "1.4rem",
              margin: ".45rem",
            }}
            title="View"
          />
        </div>
      </td>
    </tr>
  );
};

export default RowItem;
