import { useState } from "react";

import "./App.css";
import Navbar from "./components/common/Navbar";
import Home from "./components/Home";
import List from "./components/employee/List";
function App() {
  return (
    <>
      <div className="container mx-auto grid items-center py-2">
        <Navbar />
        {/* <Home /> */}
        <List />
      </div>
    </>
  );
}

export default App;
