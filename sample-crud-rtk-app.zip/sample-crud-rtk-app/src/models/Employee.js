class EmployeeModel {
  constructor() {
    this.fname = "";
    this.lname = "";
    this.address = "";
    this.position = "";
    this.organization = "";
    this.isactive = true;
    this.email = "";
    this.doj = "";
  }

  //   constructor(fname, lname, address, position, organization, email, doj) {
  //     this.fname = fname;
  //     this.lname = lname;
  //     this.address = address;
  //     this.position = position;
  //     this.organization = organization;
  //     this.isactive = true;
  //     this.email = email;
  //     this.doj = doj;
  //   }
}

export default EmployeeModel;
