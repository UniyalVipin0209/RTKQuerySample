import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import EmployeeModel from "../models/Employee";

export const employeeapi = createApi({
  baseQuery: fetchBaseQuery({
    baseUrl: "http://localhost:3000",
  }),
  endpoints: (builder) => ({
    getEmployees: builder.query({
      query: () => "/employees",
      method: "GET",
      providesTags: ["Employees"],
    }),
    // getEmployeeById: builder.query({
    //   query: ({ id }) => `/employees/${id}`,
    //   method: "GET",
    //   providesTags: ["Employees"],
    // }),
    addEmployee: builder.mutation({
      query: (newemployee) => ({
        url: "/employees",
        method: "POST",
        body: newemployee,
      }),
      invalidatesTags: ["Employees"],
    }),
    deleteEmployee: builder.mutation({
      query: ({ id }) => ({
        url: `/employees/${id}`,
        method: "DELETE",
        body: id,
      }),
      invalidatesTags: ["Employees"],
    }),
  }),
});

export const {
  useGetEmployeesQuery,
  useAddEmployeeMutation,
  useDeleteEmployeeMutation,
} = employeeapi;
